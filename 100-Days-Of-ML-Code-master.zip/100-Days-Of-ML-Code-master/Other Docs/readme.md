Images for representation
